import chalk from "chalk";
import { BRANDING, CONFIG } from "./src/config/config.js";
import { startWhatsApp } from "./src/whatsapp/socket.js";
import { startTelegramBot } from "./src/telegram/bot.js";
import { startKeepAliveServer } from "./src/lib/keepalive.js";

console.log(chalk.cyan(`\n=== ${BRANDING.name} ===`));
console.log(chalk.cyan(`Owner: ${BRANDING.owner}\n`));

// Small HTTP server so a free-tier host (e.g. Render Web Service) can be
// kept awake by an external pinger like UptimeRobot. Harmless if unused.
startKeepAliveServer();

// Start the Telegram pairing bot first so /pair is available immediately.
startTelegramBot();

// Start WhatsApp. If PAIR_NUMBER is set in .env, a pairing code is
// requested automatically on boot (also printed in the terminal).
// Otherwise, pair later any time via the Telegram bot's /pair command.
startWhatsApp({ requestPairingFor: CONFIG.pairNumber || null });
