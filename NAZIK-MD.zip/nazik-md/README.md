# NAZIK-MD

A multi-feature WhatsApp bot (auto-reply, group tools, download tools, DP tools, emoji/sticker tools, group & channel JID tools), with pairing done through a companion Telegram bot — no QR code scanning needed.

- **Bot name:** NAZIK-MD
- **Owner:** Ghullam Nazik Mastoi

## Features

- ✅ Auto-reply to greetings/common messages
- ✅ Group tools: tagall, kick, promote, demote, group link, group info, welcome toggle
- ✅ Download tools: YouTube (mp3/mp4), Facebook, TikTok, Instagram
- ✅ DP tools: set bot profile picture, get a user's profile picture, set bot name/bio
- ✅ Media tools: sticker maker, sticker → image, emoji packs, emoji reactions
- ✅ JID tools: get group JID, get channel JID, get current chat JID
- ✅ Pairing via a Telegram bot (`/pair <number>`) — no QR scanning

## 1. Install dependencies

```bash
npm install
```

## 2. Configure environment

Copy `.env.example` to `.env` and fill in the values:

```bash
cp .env.example .env
```

| Variable | Required | Description |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | Yes, for Telegram pairing | Get this from [@BotFather](https://t.me/BotFather) on Telegram |
| `TELEGRAM_OWNER_ID` | Recommended | Your numeric Telegram user ID, so only you can use `/pair`. Get it from [@userinfobot](https://t.me/userinfobot) |
| `OWNER_NUMBER` | Yes | Your WhatsApp number (digits only, country code, no +) |
| `PAIR_NUMBER` | Optional | If set, a pairing code is requested automatically on startup (also printed in the terminal). Leave empty to pair only via Telegram's `/pair` command. |
| `BOT_NAME` | No | Defaults to `NAZIK-MD` |
| `OWNER_NAME` | No | Defaults to `Ghullam Nazik Mastoi` |
| `AUTO_FOLLOW_CHANNEL` | No | WhatsApp channel invite link the bot auto-follows every time it connects. Defaults to the channel you provided. |
| `DOWNLOAD_API_BASE` | For download commands | See "Download tools" section below |
| `DOWNLOAD_API_KEY` | If your provider needs one | See below |

## 3. Run the bot

```bash
npm start
```

This starts **both** the WhatsApp connection and the Telegram pairing bot together.

## 4. Pair your WhatsApp number

You have two options:

**Option A — via Telegram (recommended, matches what you asked for):**
1. Open your Telegram bot (the one from `TELEGRAM_BOT_TOKEN`).
2. Send `/pair 923001234567` (replace with your WhatsApp number, country code first, no `+` or spaces).
3. The bot replies with an 8-character pairing code.
4. On your phone: WhatsApp → Settings → Linked Devices → Link a Device → **Link with phone number instead** → enter the code.

**Option B — automatic on startup:**
Set `PAIR_NUMBER` in `.env` before running `npm start`; the code will also be printed in your hosting panel's console/logs.

Once paired, session credentials are saved in the `sessions/` folder so you don't need to pair again after restarts (as long as you don't delete that folder or log the device out from your phone).

## 5. Hosting

This is a plain Node.js app — you can run it on any Node.js host (VPS, Railway, Render, a VPS with PM2, etc.):

1. Upload/clone the project to your host.
2. Set the environment variables from `.env.example` in your host's dashboard (or upload a `.env` file).
3. Set the start command to `npm install && npm start`.
4. Make sure the `sessions/` and `database/` folders are on **persistent** storage (not wiped on redeploy), otherwise you'll have to re-pair every time the bot restarts.

If your host supports a `Procfile` or similar, use:
```
worker: npm start
```

## 6. Download tools — important note

Free download APIs for YouTube/Facebook/TikTok/Instagram change often and some shut down without notice. `src/commands/download.js` is written so you only need to edit `DOWNLOAD_API_BASE` (and optionally `DOWNLOAD_API_KEY`) in `.env` to point to whichever downloader API you choose to use (for example one from RapidAPI, or your own self-hosted downloader). The command logic (sending the file to WhatsApp, error handling, etc.) is already complete — you just need a working API endpoint plugged in.

## Commands

Type `.menu` in any chat with the bot to see the full, live list of commands grouped by category.

## Project structure

```
nazik-md/
├── index.js                 # entrypoint — starts WhatsApp + Telegram bot
├── .env.example
├── src/
│   ├── config/config.js     # branding + env config
│   ├── lib/database.js      # simple JSON storage (groups/users)
│   ├── whatsapp/
│   │   ├── socket.js        # Baileys connection + pairing code logic
│   │   └── handler.js       # message router
│   ├── commands/
│   │   ├── index.js         # registers all commands
│   │   ├── general.js       # menu, ping, owner, jid tools
│   │   ├── group.js         # tagall, kick, promote, demote, etc
│   │   ├── media.js         # sticker, toimg, emoji, react
│   │   ├── download.js      # ytmp3/ytmp4/fbdl/tiktok/igdl
│   │   ├── dp.js             # setpp, getpp, setname, setbio
│   │   └── autoreply.js     # keyword-based auto replies
│   └── telegram/
│       └── bot.js           # Telegram /pair command
├── sessions/                 # WhatsApp auth state (auto-created)
└── database/                  # JSON data (auto-created)
```

## License

Private/internal use — built for Ghullam Nazik Mastoi.
