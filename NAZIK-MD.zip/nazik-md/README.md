# NAZIK-MD

A multi-feature WhatsApp bot (auto-reply, group tools, download tools, DP tools, emoji/sticker tools, group & channel JID tools), with pairing done through a companion Telegram bot — no QR code scanning needed.

- **Bot name:** NAZIK-MD
- **Owner:** Ghullam Nazik Mastoi

## Features

- ✅ Auto-reply to greetings/common messages
- ✅ Group tools: tagall, kick, promote, demote, group link, group info, welcome toggle
- ✅ Download tools: YouTube (mp3/mp4), Facebook, TikTok, Instagram
- ✅ DP tools: set bot profile picture, get a user's profile picture, set bot name/bio
- ✅ Media tools: sticker maker, sticker → image, emoji packs, emoji reactions
- ✅ JID tools: get group JID, get channel JID, get current chat JID
- ✅ Pairing via a Telegram bot (`/pair <number>`) — no QR scanning

## 1. Install dependencies

```bash
npm install
```

## 2. Configure environment

Copy `.env.example` to `.env` and fill in the values:

```bash
cp .env.example .env
```

| Variable | Required | Description |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | Yes, for Telegram pairing | Get this from [@BotFather](https://t.me/BotFather) on Telegram |
| `TELEGRAM_OWNER_ID` | Recommended | Your numeric Telegram user ID, so only you can use `/pair`. Get it from [@userinfobot](https://t.me/userinfobot) |
| `OWNER_NUMBER` | Yes | Your WhatsApp number (digits only, country code, no +) |
| `PAIR_NUMBER` | Optional | If set, a pairing code is requested automatically on startup (also printed in the terminal). Leave empty to pair only via Telegram's `/pair` command. |
| `BOT_NAME` | No | Defaults to `NAZIK-MD` |
| `OWNER_NAME` | No | Defaults to `Ghullam Nazik Mastoi` |
| `AUTO_FOLLOW_CHANNEL` | No | WhatsApp channel invite link the bot auto-follows every time it connects. Defaults to the channel you provided. |
| `DOWNLOAD_API_BASE` | For download commands | See "Download tools" section below |
| `DOWNLOAD_API_KEY` | If your provider needs one | See below |

## 3. Run the bot

```bash
npm start
```

This starts **both** the WhatsApp connection and the Telegram pairing bot together.

## 4. Pair your WhatsApp number

You have two options:

**Option A — via Telegram (recommended, matches what you asked for):**
1. Open your Telegram bot (the one from `TELEGRAM_BOT_TOKEN`).
2. Send `/pair 923001234567` (replace with your WhatsApp number, country code first, no `+` or spaces).
3. The bot replies with an 8-character pairing code.
4. On your phone: WhatsApp → Settings → Linked Devices → Link a Device → **Link with phone number instead** → enter the code.

**Option B — automatic on startup:**
Set `PAIR_NUMBER` in `.env` before running `npm start`; the code will also be printed in your hosting panel's console/logs.

Once paired, session credentials are saved in the `sessions/` folder so you don't need to pair again after restarts (as long as you don't delete that folder or log the device out from your phone).

## 5. Hosting on Render (Free Web Service + UptimeRobot)

Agar paid worker nahi lena, **Free Web Service** bhi chalega — bas usko sona (sleep) na dene ke liye UptimeRobot se ping karwate rahna hoga. **Important trade-off:** free tier pe persistent disk nahi milti, is liye har restart/redeploy pe session uड़ sकता है aur tumhe Telegram `/pair` dobara bhejna pad sakta hai.

### Render dashboard pe exactly kahan kya fill karna hai

1. **render.com** pe login/signup karo → **New +** → **Blueprint** (agar GitHub repo connect kiya hai, `render.yaml` khud sab fields bhar dega) — ya **New +** → **Web Service** manually.
2. **Connect repository** — apna GitHub repo select karo jisme ye project pushed ho.
3. Ye fields fill karni hain (manual route mein):
   - **Name**: `nazik-md`
   - **Runtime**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type / Plan**: `Free`
4. **Environment Variables** section mein ye sab add karo (Key = Value):

   | Key | Value |
   |---|---|
   | `TELEGRAM_BOT_TOKEN` | apna BotFather se liya hua token |
   | `TELEGRAM_OWNER_ID` | apna Telegram numeric ID |
   | `OWNER_NUMBER` | `923321675331` |
   | `PAIR_NUMBER` | khali chhod do (Telegram `/pair` se karoge) |
   | `BOT_NAME` | `NAZIK-MD` |
   | `OWNER_NAME` | `Ghullam Nazik Mastoi` |
   | `AUTO_FOLLOW_CHANNEL` | `https://whatsapp.com/channel/0029VbDYi1p2v1J0m1mp3H1D` |
   | `DOWNLOAD_API_BASE` | jo bhi downloader API use karoge uska URL |
   | `DOWNLOAD_API_KEY` | agar API ko key chahiye |

5. **Create Web Service** dabao. Deploy hone ke baad Render ek public URL dega jaisे `https://nazik-md.onrender.com`.
6. Render → **Logs** tab se dekho bot start hua ya nahi.
7. Telegram pe apne bot ko `/pair 923321675331` bhejo, pairing code milega, WhatsApp → Linked Devices → "Link with phone number" mein daal do.

### UptimeRobot setup (sleep rokne ke liye)

1. [uptimerobot.com](https://uptimerobot.com) pe free account banao.
2. **+ Add New Monitor**
3. Fields fill karo:
   - **Monitor Type**: `HTTP(s)`
   - **Friendly Name**: `NAZIK-MD`
   - **URL (or IP)**: wahi Render URL jo step 5 mein mila, e.g. `https://nazik-md.onrender.com`
   - **Monitoring Interval**: `5 minutes`
4. Save karo. Ab UptimeRobot har 5 min mein tumhare bot ko ping karega aur Render ko sone nahi dega.

## 6. Hosting on Render (Paid Background Worker — more reliable)

A WhatsApp bot needs to stay connected 24/7, so deploy it as a **Background Worker**, not a Web Service — Render's free Web Service tier sleeps after 15 minutes of inactivity, which would keep dropping the WhatsApp connection. Background Workers have no free tier; the cheapest option is the **Starter plan (~$7/month)**.

### Option A — one-click with the included `render.yaml`

1. Push this project to a GitHub (or GitLab) repository.
2. On [render.com](https://render.com) → **New** → **Blueprint**, and point it at your repo. Render will read `render.yaml` automatically and create the worker, a 1 GB persistent disk (for `sessions/` and `database/`), and the env vars.
3. Fill in the env vars marked `sync: false` in Render's dashboard (`TELEGRAM_BOT_TOKEN`, `TELEGRAM_OWNER_ID`, `DOWNLOAD_API_BASE`, etc.) — these are secrets so Render won't store them in the blueprint file.
4. Deploy. Watch the **Logs** tab for the pairing code if you set `PAIR_NUMBER`, or just message your Telegram bot's `/pair` command once it's live.

### Option B — manual setup

1. On Render: **New** → **Background Worker**, connect your repo.
2. Build command: `npm install`
3. Start command: `npm start`
4. Add a **Disk** (Render dashboard → your service → Disks) mounted at the project root, so `sessions/` and `database/` survive restarts and redeploys. Without this, you'll have to re-pair every time Render redeploys the service.
5. Add all the environment variables from `.env.example` under **Environment**.
6. Deploy, then pair via your Telegram bot's `/pair <number>` command.

### Why not Render's free tier?

Free Web Services spin down after 15 minutes idle and spin back up on the next request — but nothing "requests" a WhatsApp bot, so it would sleep almost immediately and your WhatsApp session would keep disconnecting/reconnecting, which is unreliable for a bot meant to run continuously. The Starter worker plan avoids this.

## 7. Download tools — important note

Free download APIs for YouTube/Facebook/TikTok/Instagram change often and some shut down without notice. `src/commands/download.js` is written so you only need to edit `DOWNLOAD_API_BASE` (and optionally `DOWNLOAD_API_KEY`) in `.env` to point to whichever downloader API you choose to use (for example one from RapidAPI, or your own self-hosted downloader). The command logic (sending the file to WhatsApp, error handling, etc.) is already complete — you just need a working API endpoint plugged in.

## Commands

Type `.menu` in any chat with the bot to see the full, live list of commands grouped by category. Quick reference:

**General:** menu, ping, owner, runtime, alive, jid, groupjid, channeljid
**Group Tools:** tagall, kick, promote, demote, mute, unmute, grouplink, groupinfo, setgname, setgdesc, listadmins, revoke, antilink, welcome, gettxt
**Media Tools:** sticker, toimg, emoji, react
**Download Tools:** ytmp3, ytmp4, fbdl, tiktok, igdl
**DP Tools:** setpp, getpp, setname, setbio
**Owner Tools:** block, unblock, broadcast

## Project structure

```
nazik-md/
├── index.js                 # entrypoint — starts WhatsApp + Telegram bot
├── .env.example
├── src/
│   ├── config/config.js     # branding + env config
│   ├── lib/database.js      # simple JSON storage (groups/users)
│   ├── whatsapp/
│   │   ├── socket.js        # Baileys connection + pairing code logic
│   │   └── handler.js       # message router
│   ├── commands/
│   │   ├── index.js         # registers all commands
│   │   ├── general.js       # menu, ping, owner, jid tools
│   │   ├── group.js         # tagall, kick, promote, demote, etc
│   │   ├── media.js         # sticker, toimg, emoji, react
│   │   ├── download.js      # ytmp3/ytmp4/fbdl/tiktok/igdl
│   │   ├── dp.js             # setpp, getpp, setname, setbio
│   │   └── autoreply.js     # keyword-based auto replies
│   └── telegram/
│       └── bot.js           # Telegram /pair command
├── sessions/                 # WhatsApp auth state (auto-created)
└── database/                  # JSON data (auto-created)
```

## License

Private/internal use — built for Ghullam Nazik Mastoi.
