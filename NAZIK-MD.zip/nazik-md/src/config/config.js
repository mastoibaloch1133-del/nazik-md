import "dotenv/config";

export const BRANDING = {
  name: process.env.BOT_NAME || "NAZIK-MD",
  owner: process.env.OWNER_NAME || "Ghullam Nazik Mastoi",
  footer: "> _Powered by NAZIK-MD_",
  version: "1.0.0",
};

export const CONFIG = {
  ownerNumber: (process.env.OWNER_NUMBER || "").replace(/\D/g, ""),
  pairNumber: (process.env.PAIR_NUMBER || "").replace(/\D/g, ""),
  autoReply: String(process.env.AUTO_REPLY || "true") === "true",
  publicMode: String(process.env.PUBLIC_MODE || "true") === "true",
  prefix: process.env.PREFIX || ".",
  autoFollowChannel:
    process.env.AUTO_FOLLOW_CHANNEL ||
    "https://whatsapp.com/channel/0029VbDYi1p2v1J0m1mp3H1D",
};

export const TELEGRAM_CONFIG = {
  botToken: process.env.TELEGRAM_BOT_TOKEN || "",
  ownerId: process.env.TELEGRAM_OWNER_ID || "",
};
