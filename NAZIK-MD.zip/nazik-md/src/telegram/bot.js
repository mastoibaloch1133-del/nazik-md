import { Bot, InlineKeyboard } from "grammy";
import { TELEGRAM_CONFIG, BRANDING } from "../config/config.js";
import { requestPairingCode } from "../whatsapp/socket.js";

if (!TELEGRAM_CONFIG.botToken) {
  console.log("[NAZIK-MD] TELEGRAM_BOT_TOKEN missing — Telegram pairing bot not started.");
}

// Raw inline keyboard helper for Telegram's "copy to clipboard" button
// (copy_text field, Bot API 7.x+). grammy's InlineKeyboard class doesn't
// have a dedicated method for it yet, so we build the row manually.
function copyButtonRow(label, textToCopy) {
  return [{ text: label, copy_text: { text: textToCopy } }];
}

export function startTelegramBot() {
  if (!TELEGRAM_CONFIG.botToken) return null;

  const bot = new Bot(TELEGRAM_CONFIG.botToken);

  function isOwner(ctx) {
    if (!TELEGRAM_CONFIG.ownerId) return true; // no restriction configured
    return String(ctx.from?.id) === String(TELEGRAM_CONFIG.ownerId);
  }

  bot.command("start", (ctx) => {
    const keyboard = new InlineKeyboard()
      .text("🔗 Pair WhatsApp", "menu_pair_help")
      .row()
      .text("ℹ️ Help", "menu_help");

    return ctx.reply(
      `Welcome to ${BRANDING.name} pairing bot.\nOwner: ${BRANDING.owner}`,
      { reply_markup: keyboard }
    );
  });

  bot.command("menu", (ctx) => {
    const keyboard = new InlineKeyboard()
      .text("🔗 Pair WhatsApp", "menu_pair_help")
      .row()
      .text("ℹ️ Help", "menu_help");
    return ctx.reply(`${BRANDING.name} menu:`, { reply_markup: keyboard });
  });

  bot.callbackQuery("menu_help", async (ctx) => {
    await ctx.answerCallbackQuery();
    await ctx.reply(
      "Commands:\n/pair <number> — pair your WhatsApp\n\nOnce paired, type .menu inside any WhatsApp chat with the bot to see every WhatsApp command."
    );
  });

  bot.callbackQuery("menu_pair_help", async (ctx) => {
    await ctx.answerCallbackQuery();
    await ctx.reply(
      "Send:\n/pair <your_whatsapp_number>\n\nExample:\n/pair 923001234567\n\n(country code first, no + or spaces)"
    );
  });

  bot.command("pair", async (ctx) => {
    if (!isOwner(ctx)) return ctx.reply("❌ You are not authorized to use this bot.");

    const number = ctx.match?.toString().trim();
    if (!number || !/^\d{8,15}$/.test(number)) {
      return ctx.reply("Usage: /pair followed by your WhatsApp number\nExample: /pair 923001234567");
    }

    const keyboard = new InlineKeyboard().text("✅ I'm on the code screen — Get Code", `go_pair:${number}`);

    await ctx.reply(
      `Before tapping the button below:\n\n1. Open WhatsApp\n2. Settings → Linked Devices → Link a Device\n3. Tap "Link with phone number instead"\n4. Enter ${number} and reach the screen that asks for an 8-character code\n\nOnly THEN tap the button — the code expires in about 60 seconds, so get there first.`,
      { reply_markup: keyboard }
    );
  });

  bot.callbackQuery(/^go_pair:(\d+)$/, async (ctx) => {
    const number = ctx.match[1];
    if (!isOwner(ctx)) return ctx.answerCallbackQuery({ text: "Not authorized", show_alert: true });

    await ctx.answerCallbackQuery({ text: "Requesting code..." });
    await ctx.reply("⏳ Requesting pairing code, please wait...");

    try {
      const code = await requestPairingCode(number);
      await ctx.reply(`✅ Pairing code for ${number}:\n\n${code}\n\nEnter it now — it expires in ~60 seconds.`, {
        reply_markup: { inline_keyboard: [copyButtonRow("📋 Copy Code", code)] },
      });
    } catch (err) {
      await ctx.reply(`❌ Failed to get pairing code: ${err.message}`);
    }
  });

  bot.catch((err) => console.log("[NAZIK-MD][Telegram error]", err.message));

  bot.start();
  console.log("[NAZIK-MD] ✅ Telegram pairing bot started.");
  return bot;
}
