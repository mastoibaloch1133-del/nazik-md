import { Bot } from "grammy";
import { TELEGRAM_CONFIG, BRANDING } from "../config/config.js";
import { requestPairingCode } from "../whatsapp/socket.js";

if (!TELEGRAM_CONFIG.botToken) {
  console.log("[NAZIK-MD] TELEGRAM_BOT_TOKEN missing — Telegram pairing bot not started.");
}

export function startTelegramBot() {
  if (!TELEGRAM_CONFIG.botToken) return null;

  const bot = new Bot(TELEGRAM_CONFIG.botToken);

  function isOwner(ctx) {
    if (!TELEGRAM_CONFIG.ownerId) return true; // no restriction configured
    return String(ctx.from?.id) === String(TELEGRAM_CONFIG.ownerId);
  }

  bot.command("start", (ctx) =>
    ctx.reply(
      `👋 Welcome to *${BRANDING.name}* pairing bot.\n\nUse:\n/pair <whatsapp_number>\n\nExample:\n/pair 923001234567`,
      { parse_mode: "Markdown" }
    )
  );

  bot.command("pair", async (ctx) => {
    if (!isOwner(ctx)) return ctx.reply("❌ You are not authorized to use this bot.");

    const number = ctx.match?.toString().trim();
    if (!number || !/^\d{8,15}$/.test(number)) {
      return ctx.reply("Usage: /pair <whatsapp_number>\nExample: /pair 923001234567");
    }

    await ctx.reply("⏳ Requesting pairing code, please wait...");
    try {
      const code = await requestPairingCode(number);
      await ctx.reply(
        `✅ Pairing code for *${number}*:\n\n\`${code}\`\n\nOpen WhatsApp → Linked Devices → Link with phone number, and enter this code.`,
        { parse_mode: "Markdown" }
      );
    } catch (err) {
      await ctx.reply(`❌ Failed to get pairing code: ${err.message}`);
    }
  });

  bot.catch((err) => console.log("[NAZIK-MD][Telegram error]", err.message));

  bot.start();
  console.log("[NAZIK-MD] ✅ Telegram pairing bot started.");
  return bot;
}
