import {
  default as makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} from "@whiskeysockets/baileys";
import pino from "pino";
import chalk from "chalk";
import path from "path";
import { CONFIG, BRANDING } from "../config/config.js";
import { handleMessage } from "./handler.js";

function extractInviteCode(link) {
  try {
    const url = new URL(link);
    return url.pathname.split("/").filter(Boolean).pop();
  } catch {
    return null;
  }
}

async function followConfiguredChannel(sock) {
  if (!CONFIG.autoFollowChannel) return;
  const code = extractInviteCode(CONFIG.autoFollowChannel);
  if (!code) return;

  try {
    const metadata = await sock.newsletterMetadata("invite", code);
    if (!metadata?.id) throw new Error("Could not resolve channel JID from invite link.");
    await sock.newsletterFollow(metadata.id);
    console.log(chalk.green(`[NAZIK-MD] ✅ Auto-followed channel: ${metadata.name || metadata.id}`));
  } catch (err) {
    console.log(chalk.yellow(`[NAZIK-MD] ⚠️ Could not auto-follow channel: ${err.message}`));
  }
}

const SESSION_DIR = path.resolve("sessions");

let sockInstance = null;
let pairingResolvers = [];

/**
 * Lets other modules (e.g. the Telegram bot) await the next pairing code.
 */
export function onNextPairingCode() {
  return new Promise((resolve) => pairingResolvers.push(resolve));
}

function resolvePairingCode(code) {
  const resolvers = pairingResolvers;
  pairingResolvers = [];
  resolvers.forEach((r) => r(code));
}

export function getSocket() {
  return sockInstance;
}

export async function startWhatsApp({ requestPairingFor } = {}) {
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    auth: state,
    browser: [BRANDING.name, "Chrome", "1.0.0"],
  });

  sockInstance = sock;

  // If not registered yet and a number was supplied, request a pairing code.
  if (!sock.authState.creds.registered && requestPairingFor) {
    const number = requestPairingFor.replace(/\D/g, "");
    try {
      const code = await sock.requestPairingCode(number);
      console.log(chalk.green(`[NAZIK-MD] Pairing code for ${number}: ${code}`));
      resolvePairingCode(code);
    } catch (err) {
      console.log(chalk.red(`[NAZIK-MD] Failed to get pairing code: ${err.message}`));
    }
  }

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      console.log(chalk.yellow(`[NAZIK-MD] Connection closed (${statusCode}). Reconnecting: ${shouldReconnect}`));
      if (shouldReconnect) {
        startWhatsApp({ requestPairingFor: null });
      } else {
        console.log(chalk.red("[NAZIK-MD] Logged out. Delete the sessions folder and pair again."));
      }
    } else if (connection === "open") {
      console.log(chalk.green(`[NAZIK-MD] ✅ Connected as ${sock.user?.id}`));
      followConfiguredChannel(sock);
    }
  });

  sock.ev.on("messages.upsert", async (m) => {
    try {
      await handleMessage(sock, m);
    } catch (err) {
      console.log(chalk.red(`[NAZIK-MD] Handler error: ${err.message}`));
    }
  });

  return sock;
}

/**
 * Called by the Telegram bot's /pair command to (re)request a pairing
 * code for a specific number against the already-running socket, or to
 * bootstrap a fresh connection if none exists yet.
 */
export async function requestPairingCode(number) {
  const digits = number.replace(/\D/g, "");
  if (sockInstance && !sockInstance.authState?.creds?.registered) {
    const code = await sockInstance.requestPairingCode(digits);
    return code;
  }
  // No live unregistered socket — start one fresh for this number.
  await startWhatsApp({ requestPairingFor: digits });
  return onNextPairingCode();
}
