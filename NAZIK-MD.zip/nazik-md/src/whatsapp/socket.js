import {
  default as makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} from "@whiskeysockets/baileys";
import pino from "pino";
import chalk from "chalk";
import path from "path";
import fs from "fs-extra";
import { CONFIG, BRANDING } from "../config/config.js";
import { handleMessage } from "./handler.js";

function extractInviteCode(link) {
  try {
    const url = new URL(link);
    return url.pathname.split("/").filter(Boolean).pop();
  } catch {
    return null;
  }
}

async function followConfiguredChannel(sock) {
  if (!CONFIG.autoFollowChannel) return;
  const code = extractInviteCode(CONFIG.autoFollowChannel);
  if (!code) return;

  try {
    const metadata = await sock.newsletterMetadata("invite", code);
    if (!metadata?.id) throw new Error("Could not resolve channel JID from invite link.");
    await sock.newsletterFollow(metadata.id);
    console.log(chalk.green(`[NAZIK-MD] ✅ Auto-followed channel: ${metadata.name || metadata.id}`));
  } catch (err) {
    console.log(chalk.yellow(`[NAZIK-MD] ⚠️ Could not auto-follow channel: ${err.message}`));
  }
}

const SESSION_DIR = path.resolve("sessions");

let sockInstance = null;
let pairingResolvers = [];

/**
 * Lets other modules (e.g. the Telegram bot) await the next pairing code.
 */
export function onNextPairingCode() {
  return new Promise((resolve) => pairingResolvers.push(resolve));
}

function resolvePairingCode(code) {
  const resolvers = pairingResolvers;
  pairingResolvers = [];
  resolvers.forEach((r) => r(code));
}

export function getSocket() {
  return sockInstance;
}

export async function startWhatsApp({ requestPairingFor } = {}) {
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    auth: state,
    browser: [BRANDING.name, "Chrome", "1.0.0"],
  });

  sockInstance = sock;

  // If not registered yet and a number was supplied, request a pairing code.
  if (!sock.authState.creds.registered && requestPairingFor) {
    const number = requestPairingFor.replace(/\D/g, "");
    try {
      const code = await sock.requestPairingCode(number);
      console.log(chalk.green(`[NAZIK-MD] Pairing code for ${number}: ${code}`));
      resolvePairingCode(code);
    } catch (err) {
      console.log(chalk.red(`[NAZIK-MD] Failed to get pairing code: ${err.message}`));
    }
  }

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const registered = Boolean(sock.authState?.creds?.registered);

      // Only auto-reconnect a session that was actually paired before.
      // An unregistered socket that closes (e.g. an unused/expired
      // pairing code) has nothing worth resuming — looping reconnects
      // here is what was causing the repeated "Connection Closed"
      // errors. Just stop and wait for the next explicit /pair.
      const shouldReconnect = registered && statusCode !== DisconnectReason.loggedOut;
      console.log(chalk.yellow(`[NAZIK-MD] Connection closed (${statusCode}). Reconnecting: ${shouldReconnect}`));

      if (shouldReconnect) {
        startWhatsApp({ requestPairingFor: null });
      } else if (!registered) {
        console.log(chalk.yellow("[NAZIK-MD] Unregistered session closed. Send /pair again on Telegram to retry."));
      } else {
        console.log(chalk.red("[NAZIK-MD] Logged out. Delete the sessions folder and pair again."));
      }
    } else if (connection === "open") {
      console.log(chalk.green(`[NAZIK-MD] ✅ Connected as ${sock.user?.id}`));
      followConfiguredChannel(sock);
    }
  });

  sock.ev.on("messages.upsert", async (m) => {
    try {
      await handleMessage(sock, m);
    } catch (err) {
      console.log(chalk.red(`[NAZIK-MD] Handler error: ${err.message}`));
    }
  });

  return sock;
}

let pairingInProgress = null;

/**
 * Called by the Telegram bot's /pair command. Always tears down any
 * stale/unregistered socket and session files first, then starts a
 * completely fresh connection and requests a new pairing code. Reusing
 * an old, already-closed socket is what produced "Connection Closed"
 * errors, so we never do that.
 */
export async function requestPairingCode(number) {
  // Prevent two /pair calls racing each other and corrupting the session.
  if (pairingInProgress) {
    return pairingInProgress;
  }

  const digits = number.replace(/\D/g, "");

  pairingInProgress = (async () => {
    if (sockInstance && !sockInstance.authState?.creds?.registered) {
      try {
        sockInstance.end?.(new Error("restarting for a new pairing code"));
      } catch {
        /* ignore */
      }
      sockInstance = null;
      await fs.remove(SESSION_DIR).catch(() => {});
    }

    await startWhatsApp({ requestPairingFor: digits });
    return onNextPairingCode();
  })();

  try {
    return await pairingInProgress;
  } finally {
    pairingInProgress = null;
  }
}
