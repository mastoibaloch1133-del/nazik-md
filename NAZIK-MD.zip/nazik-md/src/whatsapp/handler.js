import { CONFIG } from "../config/config.js";
import { touchUser, getGroupSettings } from "../lib/database.js";
import { commands } from "../commands/index.js";
import { runAutoReply } from "../commands/autoreply.js";

const INVITE_LINK_RE = /chat\.whatsapp\.com\/[A-Za-z0-9]+/i;

async function enforceAntilink(sock, msg, { from, sender, text }) {
  if (!INVITE_LINK_RE.test(text)) return false;

  const settings = getGroupSettings(from);
  if (!settings.antilink) return false;

  try {
    const metadata = await sock.groupMetadata(from);
    const participant = metadata.participants.find((p) => p.id === sender);
    if (participant?.admin) return false; // admins are exempt

    await sock.sendMessage(from, { delete: msg.key });
    await sock.sendMessage(from, {
      text: `🚫 @${sender.split("@")[0]} group links aren't allowed here.`,
      mentions: [sender],
    });
    return true;
  } catch {
    return false;
  }
}

function extractText(msg) {
  const m = msg.message;
  if (!m) return "";
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ""
  );
}

export async function handleMessage(sock, upsert) {
  const msg = upsert.messages?.[0];
  if (!msg || !msg.message || msg.key.fromMe) return;

  const from = msg.key.remoteJid;
  const sender = msg.key.participant || msg.key.remoteJid;
  const isGroup = from.endsWith("@g.us");
  const text = extractText(msg).trim();

  touchUser(sender);

  if (isGroup && text) {
    const deleted = await enforceAntilink(sock, msg, { from, sender, text });
    if (deleted) return;
  }

  if (!text.startsWith(CONFIG.prefix)) {
    if (CONFIG.autoReply) {
      await runAutoReply(sock, msg, { from, sender, isGroup, text });
    }
    return;
  }

  const [cmdRaw, ...args] = text.slice(CONFIG.prefix.length).trim().split(/\s+/);
  const cmdName = cmdRaw.toLowerCase();
  const command = commands.get(cmdName);

  if (!command) return;

  const ctx = {
    sock,
    msg,
    from,
    sender,
    isGroup,
    args,
    text,
    reply: (content) => sock.sendMessage(from, { text: content }, { quoted: msg }),
  };

  try {
    await command.run(ctx);
  } catch (err) {
    await ctx.reply(`❌ Error: ${err.message}`);
  }
}
