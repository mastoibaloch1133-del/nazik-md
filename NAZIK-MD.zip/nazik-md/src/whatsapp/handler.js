import { CONFIG } from "../config/config.js";
import { touchUser } from "../lib/database.js";
import { commands } from "../commands/index.js";
import { runAutoReply } from "../commands/autoreply.js";

function extractText(msg) {
  const m = msg.message;
  if (!m) return "";
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ""
  );
}

export async function handleMessage(sock, upsert) {
  const msg = upsert.messages?.[0];
  if (!msg || !msg.message || msg.key.fromMe) return;

  const from = msg.key.remoteJid;
  const sender = msg.key.participant || msg.key.remoteJid;
  const isGroup = from.endsWith("@g.us");
  const text = extractText(msg).trim();

  touchUser(sender);

  if (!text.startsWith(CONFIG.prefix)) {
    if (CONFIG.autoReply) {
      await runAutoReply(sock, msg, { from, sender, isGroup, text });
    }
    return;
  }

  const [cmdRaw, ...args] = text.slice(CONFIG.prefix.length).trim().split(/\s+/);
  const cmdName = cmdRaw.toLowerCase();
  const command = commands.get(cmdName);

  if (!command) return;

  const ctx = {
    sock,
    msg,
    from,
    sender,
    isGroup,
    args,
    text,
    reply: (content) => sock.sendMessage(from, { text: content }, { quoted: msg }),
  };

  try {
    await command.run(ctx);
  } catch (err) {
    await ctx.reply(`❌ Error: ${err.message}`);
  }
}
