import { BRANDING } from "../config/config.js";

// key: array of trigger words (lowercase, matched as substring)
// value: reply text
const RULES = [
  {
    triggers: ["hi", "hello", "salam", "assalamualaikum", "asalamalaikum"],
    reply: `👋 Hello! Main *${BRANDING.name}* hoon.\nType *.menu* to see all commands.`,
  },
  {
    triggers: ["owner", "who made you", "banaya"],
    reply: `🤖 Mujhe *${BRANDING.owner}* ne banaya hai.\nType *.owner* for contact.`,
  },
];

export async function runAutoReply(sock, msg, { from, text }) {
  if (!text) return;
  const lower = text.toLowerCase();

  for (const rule of RULES) {
    if (rule.triggers.some((t) => lower.includes(t))) {
      await sock.sendMessage(from, { text: rule.reply }, { quoted: msg });
      return;
    }
  }
}
