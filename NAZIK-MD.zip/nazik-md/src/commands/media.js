import { downloadMediaMessage } from "@whiskeysockets/baileys";

const EMOJI_PACKS = {
  love: ["❤️", "💕", "💖", "💗", "💓", "💞", "💘", "💝"],
  happy: ["😀", "😁", "😄", "😆", "😊", "🥳", "😎", "🤩"],
  sad: ["😢", "😭", "😞", "😔", "😟", "🥺", "😩", "😿"],
  fire: ["🔥", "💯", "⚡", "✨", "🌟", "💥", "🚀", "👑"],
};

function getQuotedMessageNode(ctx) {
  const contextInfo = ctx.msg.message?.extendedTextMessage?.contextInfo;
  const quoted = contextInfo?.quotedMessage;
  if (!quoted) return null;
  return {
    key: {
      remoteJid: ctx.from,
      id: contextInfo.stanzaId,
      participant: contextInfo.participant,
    },
    message: quoted,
  };
}

export const mediaCommands = [
  {
    name: "sticker",
    aliases: ["s"],
    category: "Media Tools",
    description: "Convert a replied image/video into a sticker",
    run: async (ctx) => {
      const quotedNode = getQuotedMessageNode(ctx);
      const target = quotedNode || ctx.msg;
      const hasMedia =
        target.message?.imageMessage || target.message?.videoMessage;

      if (!hasMedia) {
        return ctx.reply("❌ Reply to an image or short video with .sticker");
      }

      const buffer = await downloadMediaMessage(
        target,
        "buffer",
        {},
        { reuploadRequest: ctx.sock.updateMediaMessage }
      );

      await ctx.sock.sendMessage(
        ctx.from,
        { sticker: buffer },
        { quoted: ctx.msg }
      );
    },
  },
  {
    name: "toimg",
    category: "Media Tools",
    description: "Convert a replied sticker back to an image",
    run: async (ctx) => {
      const quotedNode = getQuotedMessageNode(ctx);
      if (!quotedNode?.message?.stickerMessage) {
        return ctx.reply("❌ Reply to a sticker with .toimg");
      }
      const buffer = await downloadMediaMessage(
        quotedNode,
        "buffer",
        {},
        { reuploadRequest: ctx.sock.updateMediaMessage }
      );
      await ctx.sock.sendMessage(
        ctx.from,
        { image: buffer, caption: "✅ Converted to image" },
        { quoted: ctx.msg }
      );
    },
  },
  {
    name: "emoji",
    aliases: ["emojimix"],
    category: "Media Tools",
    description: "Send an emoji pack: .emoji love/happy/sad/fire",
    run: async (ctx) => {
      const pack = ctx.args[0]?.toLowerCase();
      if (!pack || !EMOJI_PACKS[pack]) {
        return ctx.reply(
          `Usage: .emoji <pack>\nAvailable packs: ${Object.keys(EMOJI_PACKS).join(", ")}`
        );
      }
      await ctx.reply(EMOJI_PACKS[pack].join(" "));
    },
  },
  {
    name: "react",
    category: "Media Tools",
    description: "React to the replied message with an emoji: .react 🔥",
    run: async (ctx) => {
      const emoji = ctx.args[0];
      const contextInfo = ctx.msg.message?.extendedTextMessage?.contextInfo;
      if (!emoji || !contextInfo?.stanzaId) {
        return ctx.reply("Usage: reply to a message with .react <emoji>");
      }
      await ctx.sock.sendMessage(ctx.from, {
        react: {
          text: emoji,
          key: {
            remoteJid: ctx.from,
            id: contextInfo.stanzaId,
            participant: contextInfo.participant,
          },
        },
      });
    },
  },
];
