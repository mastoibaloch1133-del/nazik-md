import { BRANDING, CONFIG } from "../config/config.js";
import { listCommandsByCategory } from "./index.js";

export const generalCommands = [
  {
    name: "menu",
    aliases: ["help"],
    category: "General",
    description: "Show the full command list",
    run: async (ctx) => {
      // listCommandsByCategory is wired up after this module loads (index.js),
      // so we build the text lazily at call time.
      const { listCommandsByCategory: list } = await import("./index.js");
      const categories = list();
      let text = `╭─❖ *${BRANDING.name}* ❖─╮\n`;
      text += `│ Owner: ${BRANDING.owner}\n`;
      text += `│ Prefix: ${CONFIG.prefix}\n`;
      text += `╰────────────╯\n\n`;

      for (const [cat, cmds] of Object.entries(categories)) {
        text += `*◦ ${cat}*\n`;
        for (const c of cmds) {
          text += `  ${CONFIG.prefix}${c.name} - ${c.description}\n`;
        }
        text += `\n`;
      }

      text += BRANDING.footer;
      await ctx.reply(text);
    },
  },
  {
    name: "ping",
    category: "General",
    description: "Check bot response speed",
    run: async (ctx) => {
      const start = Date.now();
      await ctx.reply("🏓 Pinging...");
      const took = Date.now() - start;
      await ctx.reply(`🏓 Pong! ${took}ms`);
    },
  },
  {
    name: "owner",
    category: "General",
    description: "Get owner contact card",
    run: async (ctx) => {
      await ctx.reply(
        `👑 *Owner*: ${BRANDING.owner}\n🤖 *Bot*: ${BRANDING.name}\n\n${BRANDING.footer}`
      );
    },
  },
  {
    name: "alive",
    category: "General",
    description: "Check if the bot is online",
    run: async (ctx) => {
      await ctx.reply(`✅ *${BRANDING.name}* is alive and running!\n${BRANDING.footer}`);
    },
  },
  {
    name: "jid",
    category: "General",
    description: "Get the JID of this chat (group or channel)",
    run: async (ctx) => {
      await ctx.reply(`🆔 Chat JID:\n${ctx.from}`);
    },
  },
  {
    name: "groupjid",
    category: "General",
    description: "Get the current group's JID",
    run: async (ctx) => {
      if (!ctx.isGroup) return ctx.reply("❌ This command only works in groups.");
      await ctx.reply(`🆔 Group JID:\n${ctx.from}`);
    },
  },
  {
    name: "channeljid",
    category: "General",
    description: "List JIDs of WhatsApp channels/newsletters the bot follows",
    run: async (ctx) => {
      try {
        const list = await ctx.sock.newsletterMetadata?.("invite", ctx.from).catch(() => null);
        if (list?.id) {
          return ctx.reply(`🆔 Channel JID:\n${list.id}`);
        }
        await ctx.reply(
          "ℹ️ Send this command inside the channel chat itself, or reply with a channel invite link to resolve its JID."
        );
      } catch (err) {
        await ctx.reply(`❌ Could not resolve channel JID: ${err.message}`);
      }
    },
  },
];
