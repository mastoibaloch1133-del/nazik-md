import { downloadMediaMessage } from "@whiskeysockets/baileys";

function getQuotedMessageNode(ctx) {
  const contextInfo = ctx.msg.message?.extendedTextMessage?.contextInfo;
  const quoted = contextInfo?.quotedMessage;
  if (!quoted) return null;
  return {
    key: {
      remoteJid: ctx.from,
      id: contextInfo.stanzaId,
      participant: contextInfo.participant,
    },
    message: quoted,
  };
}

function getMentionedOrQuotedJid(ctx) {
  const contextInfo = ctx.msg.message?.extendedTextMessage?.contextInfo;
  return contextInfo?.mentionedJid?.[0] || contextInfo?.participant || null;
}

export const dpCommands = [
  {
    name: "setpp",
    category: "DP Tools",
    description: "Set the bot's profile picture (reply to an image)",
    run: async (ctx) => {
      const quotedNode = getQuotedMessageNode(ctx);
      if (!quotedNode?.message?.imageMessage) {
        return ctx.reply("❌ Reply to an image with .setpp");
      }
      const buffer = await downloadMediaMessage(
        quotedNode,
        "buffer",
        {},
        { reuploadRequest: ctx.sock.updateMediaMessage }
      );
      await ctx.sock.updateProfilePicture(ctx.sock.user.id, buffer);
      await ctx.reply("✅ Bot profile picture updated.");
    },
  },
  {
    name: "getpp",
    aliases: ["dp"],
    category: "DP Tools",
    description: "Get a user's profile picture: .getpp (reply or mention)",
    run: async (ctx) => {
      const target = getMentionedOrQuotedJid(ctx) || ctx.sender;
      try {
        const url = await ctx.sock.profilePictureUrl(target, "image");
        await ctx.sock.sendMessage(
          ctx.from,
          { image: { url }, caption: `🖼️ Profile picture of @${target.split("@")[0]}`, mentions: [target] },
          { quoted: ctx.msg }
        );
      } catch {
        await ctx.reply("❌ This user has no visible profile picture, or privacy settings block it.");
      }
    },
  },
  {
    name: "setname",
    category: "DP Tools",
    description: "Change the bot's display name: .setname <text>",
    run: async (ctx) => {
      const name = ctx.args.join(" ");
      if (!name) return ctx.reply("Usage: .setname <new name>");
      await ctx.sock.updateProfileName(name);
      await ctx.reply(`✅ Bot name changed to: ${name}`);
    },
  },
  {
    name: "setbio",
    category: "DP Tools",
    description: "Change the bot's about/bio text: .setbio <text>",
    run: async (ctx) => {
      const bio = ctx.args.join(" ");
      if (!bio) return ctx.reply("Usage: .setbio <new bio>");
      await ctx.sock.updateProfileStatus(bio);
      await ctx.reply("✅ Bot bio updated.");
    },
  },
];
