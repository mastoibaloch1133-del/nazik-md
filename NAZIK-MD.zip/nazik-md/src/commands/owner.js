import fs from "fs-extra";
import path from "path";
import { CONFIG } from "../config/config.js";

function isOwnerSender(ctx) {
  const senderNumber = ctx.sender.split("@")[0];
  return !CONFIG.ownerNumber || senderNumber === CONFIG.ownerNumber;
}

function getQuotedOrMentioned(ctx) {
  const contextInfo = ctx.msg.message?.extendedTextMessage?.contextInfo;
  const mentioned = contextInfo?.mentionedJid || [];
  const quotedParticipant = contextInfo?.participant;
  if (mentioned.length) return mentioned;
  if (quotedParticipant) return [quotedParticipant];
  return [];
}

export const ownerCommands = [
  {
    name: "block",
    category: "Owner Tools",
    description: "Block a user (owner only, reply or mention)",
    run: async (ctx) => {
      if (!isOwnerSender(ctx)) return ctx.reply("❌ Owner only command.");
      const targets = getQuotedOrMentioned(ctx);
      if (!targets.length) return ctx.reply("❌ Reply to or mention the user to block.");
      await ctx.sock.updateBlockStatus(targets[0], "block");
      await ctx.reply("✅ User blocked.");
    },
  },
  {
    name: "unblock",
    category: "Owner Tools",
    description: "Unblock a user (owner only, reply or mention)",
    run: async (ctx) => {
      if (!isOwnerSender(ctx)) return ctx.reply("❌ Owner only command.");
      const targets = getQuotedOrMentioned(ctx);
      if (!targets.length) return ctx.reply("❌ Reply to or mention the user to unblock.");
      await ctx.sock.updateBlockStatus(targets[0], "unblock");
      await ctx.reply("✅ User unblocked.");
    },
  },
  {
    name: "broadcast",
    aliases: ["bc"],
    category: "Owner Tools",
    description: "Send a message to every known user (owner only): .broadcast <text>",
    run: async (ctx) => {
      if (!isOwnerSender(ctx)) return ctx.reply("❌ Owner only command.");
      const text = ctx.args.join(" ");
      if (!text) return ctx.reply("Usage: .broadcast <message>");

      const usersPath = path.resolve("database", "users.json");
      const users = fs.existsSync(usersPath) ? fs.readJsonSync(usersPath) : {};
      const jids = Object.keys(users);

      let sent = 0;
      for (const jid of jids) {
        try {
          await ctx.sock.sendMessage(jid, { text: `📢 Broadcast:\n\n${text}` });
          sent++;
        } catch {
          /* skip failures */
        }
      }
      await ctx.reply(`✅ Broadcast sent to ${sent}/${jids.length} users.`);
    },
  },
];
