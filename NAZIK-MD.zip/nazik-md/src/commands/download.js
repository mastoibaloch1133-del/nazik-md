import axios from "axios";

/**
 * NOTE ON DOWNLOAD APIS
 * ----------------------
 * There is no single official, permanently-free API for downloading from
 * YouTube/Facebook/TikTok/Instagram. Public mirror APIs change URLs and
 * response shapes often and some go offline without notice.
 *
 * This file is built so you only need to edit ONE place (DOWNLOAD_API_BASE
 * below, plus the small "parse" function per platform) to point at whatever
 * downloader API you choose to subscribe to (e.g. a RapidAPI downloader, or
 * your own self-hosted yt-dlp wrapper). The command logic, error handling,
 * and WhatsApp sending code already works end-to-end.
 */

const DOWNLOAD_API_BASE =
  process.env.DOWNLOAD_API_BASE || "https://api.example-downloader.com";
const DOWNLOAD_API_KEY = process.env.DOWNLOAD_API_KEY || "";

async function apiGet(pathAndQuery) {
  const url = `${DOWNLOAD_API_BASE}${pathAndQuery}`;
  const headers = DOWNLOAD_API_KEY ? { "x-api-key": DOWNLOAD_API_KEY } : {};
  const { data } = await axios.get(url, { headers, timeout: 30000 });
  return data;
}

function isUrl(str) {
  try {
    new URL(str);
    return true;
  } catch {
    return false;
  }
}

export const downloadCommands = [
  {
    name: "ytmp3",
    category: "Download Tools",
    description: "Download YouTube audio: .ytmp3 <url>",
    run: async (ctx) => {
      const url = ctx.args[0];
      if (!url || !isUrl(url)) return ctx.reply("Usage: .ytmp3 <youtube url>");
      await ctx.reply("⏳ Fetching audio...");
      try {
        const data = await apiGet(`/ytmp3?url=${encodeURIComponent(url)}`);
        const audioUrl = data.result?.download || data.download || data.url;
        if (!audioUrl) throw new Error("No download link returned by API.");
        await ctx.sock.sendMessage(
          ctx.from,
          { audio: { url: audioUrl }, mimetype: "audio/mpeg" },
          { quoted: ctx.msg }
        );
      } catch (err) {
        await ctx.reply(`❌ Failed: ${err.message}\n(Configure DOWNLOAD_API_BASE in .env to a working provider.)`);
      }
    },
  },
  {
    name: "ytmp4",
    category: "Download Tools",
    description: "Download YouTube video: .ytmp4 <url>",
    run: async (ctx) => {
      const url = ctx.args[0];
      if (!url || !isUrl(url)) return ctx.reply("Usage: .ytmp4 <youtube url>");
      await ctx.reply("⏳ Fetching video...");
      try {
        const data = await apiGet(`/ytmp4?url=${encodeURIComponent(url)}`);
        const videoUrl = data.result?.download || data.download || data.url;
        if (!videoUrl) throw new Error("No download link returned by API.");
        await ctx.sock.sendMessage(
          ctx.from,
          { video: { url: videoUrl }, caption: "✅ Downloaded" },
          { quoted: ctx.msg }
        );
      } catch (err) {
        await ctx.reply(`❌ Failed: ${err.message}\n(Configure DOWNLOAD_API_BASE in .env to a working provider.)`);
      }
    },
  },
  {
    name: "fbdl",
    aliases: ["facebook", "fb"],
    category: "Download Tools",
    description: "Download a Facebook video: .fbdl <url>",
    run: async (ctx) => {
      const url = ctx.args[0];
      if (!url || !isUrl(url)) return ctx.reply("Usage: .fbdl <facebook video url>");
      await ctx.reply("⏳ Fetching Facebook video...");
      try {
        const data = await apiGet(`/facebook?url=${encodeURIComponent(url)}`);
        const videoUrl =
          data.result?.hd || data.result?.sd || data.hd || data.sd || data.url;
        if (!videoUrl) throw new Error("No download link returned by API.");
        await ctx.sock.sendMessage(
          ctx.from,
          { video: { url: videoUrl }, caption: "✅ Downloaded from Facebook" },
          { quoted: ctx.msg }
        );
      } catch (err) {
        await ctx.reply(`❌ Failed: ${err.message}\n(Configure DOWNLOAD_API_BASE in .env to a working provider.)`);
      }
    },
  },
  {
    name: "tiktok",
    aliases: ["tt"],
    category: "Download Tools",
    description: "Download a TikTok video (no watermark): .tiktok <url>",
    run: async (ctx) => {
      const url = ctx.args[0];
      if (!url || !isUrl(url)) return ctx.reply("Usage: .tiktok <tiktok url>");
      await ctx.reply("⏳ Fetching TikTok video...");
      try {
        const data = await apiGet(`/tiktok?url=${encodeURIComponent(url)}`);
        const videoUrl = data.result?.nowm || data.result?.video || data.url;
        if (!videoUrl) throw new Error("No download link returned by API.");
        await ctx.sock.sendMessage(
          ctx.from,
          { video: { url: videoUrl }, caption: "✅ Downloaded from TikTok" },
          { quoted: ctx.msg }
        );
      } catch (err) {
        await ctx.reply(`❌ Failed: ${err.message}\n(Configure DOWNLOAD_API_BASE in .env to a working provider.)`);
      }
    },
  },
  {
    name: "igdl",
    aliases: ["instagram", "ig"],
    category: "Download Tools",
    description: "Download Instagram photo/video/reel: .igdl <url>",
    run: async (ctx) => {
      const url = ctx.args[0];
      if (!url || !isUrl(url)) return ctx.reply("Usage: .igdl <instagram url>");
      await ctx.reply("⏳ Fetching Instagram media...");
      try {
        const data = await apiGet(`/instagram?url=${encodeURIComponent(url)}`);
        const items = data.result || data.data || [];
        const list = Array.isArray(items) ? items : [items];
        if (!list.length) throw new Error("No media returned by API.");

        for (const item of list) {
          const mediaUrl = item.url || item.download;
          if (!mediaUrl) continue;
          const isVideo = /\.mp4($|\?)/i.test(mediaUrl) || item.type === "video";
          await ctx.sock.sendMessage(
            ctx.from,
            isVideo ? { video: { url: mediaUrl } } : { image: { url: mediaUrl } },
            { quoted: ctx.msg }
          );
        }
      } catch (err) {
        await ctx.reply(`❌ Failed: ${err.message}\n(Configure DOWNLOAD_API_BASE in .env to a working provider.)`);
      }
    },
  },
];
