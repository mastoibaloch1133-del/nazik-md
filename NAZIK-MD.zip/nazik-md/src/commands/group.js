import { getGroupSettings, setGroupSetting } from "../lib/database.js";

function getQuotedOrMentioned(ctx) {
  const contextInfo = ctx.msg.message?.extendedTextMessage?.contextInfo;
  const mentioned = contextInfo?.mentionedJid || [];
  const quotedParticipant = contextInfo?.participant;
  if (mentioned.length) return mentioned;
  if (quotedParticipant) return [quotedParticipant];
  return [];
}

async function requireAdmin(ctx) {
  if (!ctx.isGroup) {
    await ctx.reply("❌ This command only works in groups.");
    return false;
  }
  const metadata = await ctx.sock.groupMetadata(ctx.from);
  const participant = metadata.participants.find((p) => p.id === ctx.sender);
  const botId = ctx.sock.user.id.split(":")[0] + "@s.whatsapp.net";
  const botParticipant = metadata.participants.find((p) => p.id === botId);

  if (!participant?.admin) {
    await ctx.reply("❌ Only group admins can use this command.");
    return false;
  }
  if (!botParticipant?.admin) {
    await ctx.reply("❌ I need to be an admin to do this.");
    return false;
  }
  return true;
}

export const groupCommands = [
  {
    name: "tagall",
    category: "Group Tools",
    description: "Mention all group members",
    run: async (ctx) => {
      if (!ctx.isGroup) return ctx.reply("❌ This command only works in groups.");
      const metadata = await ctx.sock.groupMetadata(ctx.from);
      const participants = metadata.participants.map((p) => p.id);
      const text = participants.map((jid) => `@${jid.split("@")[0]}`).join(" ");
      await ctx.sock.sendMessage(ctx.from, { text, mentions: participants });
    },
  },
  {
    name: "kick",
    category: "Group Tools",
    description: "Remove a member (reply or mention)",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const targets = getQuotedOrMentioned(ctx);
      if (!targets.length) return ctx.reply("❌ Reply to or mention the user to kick.");
      await ctx.sock.groupParticipantsUpdate(ctx.from, targets, "remove");
      await ctx.reply("✅ Member removed.");
    },
  },
  {
    name: "promote",
    category: "Group Tools",
    description: "Promote a member to admin",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const targets = getQuotedOrMentioned(ctx);
      if (!targets.length) return ctx.reply("❌ Reply to or mention the user to promote.");
      await ctx.sock.groupParticipantsUpdate(ctx.from, targets, "promote");
      await ctx.reply("✅ Member promoted to admin.");
    },
  },
  {
    name: "demote",
    category: "Group Tools",
    description: "Demote an admin to member",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const targets = getQuotedOrMentioned(ctx);
      if (!targets.length) return ctx.reply("❌ Reply to or mention the user to demote.");
      await ctx.sock.groupParticipantsUpdate(ctx.from, targets, "demote");
      await ctx.reply("✅ Member demoted.");
    },
  },
  {
    name: "grouplink",
    aliases: ["glink"],
    category: "Group Tools",
    description: "Get the group's invite link",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const code = await ctx.sock.groupInviteCode(ctx.from);
      await ctx.reply(`🔗 https://chat.whatsapp.com/${code}`);
    },
  },
  {
    name: "groupinfo",
    category: "Group Tools",
    description: "Show group info",
    run: async (ctx) => {
      if (!ctx.isGroup) return ctx.reply("❌ This command only works in groups.");
      const m = await ctx.sock.groupMetadata(ctx.from);
      await ctx.reply(
        `📋 *${m.subject}*\n👥 Members: ${m.participants.length}\n🆔 JID: ${m.id}\n📝 ${m.desc?.toString() || "No description"}`
      );
    },
  },
  {
    name: "welcome",
    category: "Group Tools",
    description: "Toggle welcome messages: .welcome on/off",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const mode = ctx.args[0]?.toLowerCase();
      if (!["on", "off"].includes(mode)) return ctx.reply("Usage: .welcome on/off");
      setGroupSetting(ctx.from, "welcome", mode === "on");
      await ctx.reply(`✅ Welcome messages turned ${mode}.`);
    },
  },
];
