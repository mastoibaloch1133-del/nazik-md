import { getGroupSettings, setGroupSetting } from "../lib/database.js";
import { Buffer } from "buffer";

function getQuotedOrMentioned(ctx) {
  const contextInfo = ctx.msg.message?.extendedTextMessage?.contextInfo;
  const mentioned = contextInfo?.mentionedJid || [];
  const quotedParticipant = contextInfo?.participant;
  if (mentioned.length) return mentioned;
  if (quotedParticipant) return [quotedParticipant];
  return [];
}

async function requireAdmin(ctx) {
  if (!ctx.isGroup) {
    await ctx.reply("❌ This command only works in groups.");
    return false;
  }
  const metadata = await ctx.sock.groupMetadata(ctx.from);
  const participant = metadata.participants.find((p) => p.id === ctx.sender);
  const botId = ctx.sock.user.id.split(":")[0] + "@s.whatsapp.net";
  const botParticipant = metadata.participants.find((p) => p.id === botId);

  if (!participant?.admin) {
    await ctx.reply("❌ Only group admins can use this command.");
    return false;
  }
  if (!botParticipant?.admin) {
    await ctx.reply("❌ I need to be an admin to do this.");
    return false;
  }
  return true;
}

export const groupCommands = [
  {
    name: "tagall",
    category: "Group Tools",
    description: "Mention all group members",
    run: async (ctx) => {
      if (!ctx.isGroup) return ctx.reply("❌ This command only works in groups.");
      const metadata = await ctx.sock.groupMetadata(ctx.from);
      const participants = metadata.participants.map((p) => p.id);
      const text = participants.map((jid) => `@${jid.split("@")[0]}`).join(" ");
      await ctx.sock.sendMessage(ctx.from, { text, mentions: participants });
    },
  },
  {
    name: "kick",
    category: "Group Tools",
    description: "Remove a member (reply or mention)",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const targets = getQuotedOrMentioned(ctx);
      if (!targets.length) return ctx.reply("❌ Reply to or mention the user to kick.");
      await ctx.sock.groupParticipantsUpdate(ctx.from, targets, "remove");
      await ctx.reply("✅ Member removed.");
    },
  },
  {
    name: "promote",
    category: "Group Tools",
    description: "Promote a member to admin",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const targets = getQuotedOrMentioned(ctx);
      if (!targets.length) return ctx.reply("❌ Reply to or mention the user to promote.");
      await ctx.sock.groupParticipantsUpdate(ctx.from, targets, "promote");
      await ctx.reply("✅ Member promoted to admin.");
    },
  },
  {
    name: "demote",
    category: "Group Tools",
    description: "Demote an admin to member",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const targets = getQuotedOrMentioned(ctx);
      if (!targets.length) return ctx.reply("❌ Reply to or mention the user to demote.");
      await ctx.sock.groupParticipantsUpdate(ctx.from, targets, "demote");
      await ctx.reply("✅ Member demoted.");
    },
  },
  {
    name: "grouplink",
    aliases: ["glink"],
    category: "Group Tools",
    description: "Get the group's invite link",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const code = await ctx.sock.groupInviteCode(ctx.from);
      await ctx.reply(`🔗 https://chat.whatsapp.com/${code}`);
    },
  },
  {
    name: "groupinfo",
    category: "Group Tools",
    description: "Show group info",
    run: async (ctx) => {
      if (!ctx.isGroup) return ctx.reply("❌ This command only works in groups.");
      const m = await ctx.sock.groupMetadata(ctx.from);
      await ctx.reply(
        `📋 *${m.subject}*\n👥 Members: ${m.participants.length}\n🆔 JID: ${m.id}\n📝 ${m.desc?.toString() || "No description"}`
      );
    },
  },
  {
    name: "mute",
    category: "Group Tools",
    description: "Only admins can send messages",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      await ctx.sock.groupSettingUpdate(ctx.from, "announcement");
      await ctx.reply("🔇 Group muted — only admins can send messages now.");
    },
  },
  {
    name: "unmute",
    category: "Group Tools",
    description: "Let everyone send messages again",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      await ctx.sock.groupSettingUpdate(ctx.from, "not_announcement");
      await ctx.reply("🔊 Group unmuted — everyone can send messages.");
    },
  },
  {
    name: "setgname",
    category: "Group Tools",
    description: "Change the group name: .setgname <new name>",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const name = ctx.args.join(" ");
      if (!name) return ctx.reply("Usage: .setgname <new name>");
      await ctx.sock.groupUpdateSubject(ctx.from, name);
      await ctx.reply(`✅ Group name changed to: ${name}`);
    },
  },
  {
    name: "setgdesc",
    category: "Group Tools",
    description: "Change the group description: .setgdesc <text>",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const desc = ctx.args.join(" ");
      if (!desc) return ctx.reply("Usage: .setgdesc <new description>");
      await ctx.sock.groupUpdateDescription(ctx.from, desc);
      await ctx.reply("✅ Group description updated.");
    },
  },
  {
    name: "listadmins",
    aliases: ["admins"],
    category: "Group Tools",
    description: "List all group admins",
    run: async (ctx) => {
      if (!ctx.isGroup) return ctx.reply("❌ This command only works in groups.");
      const metadata = await ctx.sock.groupMetadata(ctx.from);
      const admins = metadata.participants.filter((p) => p.admin);
      if (!admins.length) return ctx.reply("No admins found.");
      const mentions = admins.map((a) => a.id);
      const text = admins.map((a) => `👑 @${a.id.split("@")[0]}`).join("\n");
      await ctx.sock.sendMessage(ctx.from, { text, mentions }, { quoted: ctx.msg });
    },
  },
  {
    name: "revoke",
    aliases: ["revokelink"],
    category: "Group Tools",
    description: "Revoke and regenerate the group invite link",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const code = await ctx.sock.groupRevokeInvite(ctx.from);
      await ctx.reply(`✅ Invite link reset.\n🔗 https://chat.whatsapp.com/${code}`);
    },
  },
  {
    name: "antilink",
    category: "Group Tools",
    description: "Auto-delete WhatsApp group invite links from non-admins: .antilink on/off",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const mode = ctx.args[0]?.toLowerCase();
      if (!["on", "off"].includes(mode)) return ctx.reply("Usage: .antilink on/off");
      setGroupSetting(ctx.from, "antilink", mode === "on");
      await ctx.reply(`✅ Antilink turned ${mode}.`);
    },
  },
  {
    name: "gettxt",
    aliases: ["getnumbers"],
    category: "Group Tools",
    description: "DM you a .txt file with every member's number",
    run: async (ctx) => {
      if (!ctx.isGroup) return ctx.reply("❌ This command only works in groups.");

      const metadata = await ctx.sock.groupMetadata(ctx.from);
      const numbers = metadata.participants
        .map((p) => p.id.split("@")[0])
        .filter((n) => /^\d+$/.test(n));

      const content = numbers.join("\n");
      const fileBuffer = Buffer.from(content, "utf-8");

      await ctx.sock.sendMessage(ctx.sender, {
        document: fileBuffer,
        fileName: `${metadata.subject.replace(/[^\w\- ]/g, "")}-numbers.txt`,
        mimetype: "text/plain",
        caption: `📄 ${numbers.length} numbers from "${metadata.subject}"`,
      });

      await ctx.reply("✅ Sent you the numbers list in DM.");
    },
  },
  {
    name: "welcome",
    category: "Group Tools",
    description: "Toggle welcome messages: .welcome on/off",
    run: async (ctx) => {
      if (!(await requireAdmin(ctx))) return;
      const mode = ctx.args[0]?.toLowerCase();
      if (!["on", "off"].includes(mode)) return ctx.reply("Usage: .welcome on/off");
      setGroupSetting(ctx.from, "welcome", mode === "on");
      await ctx.reply(`✅ Welcome messages turned ${mode}.`);
    },
  },
];
