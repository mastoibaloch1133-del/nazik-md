import { generalCommands } from "./general.js";
import { groupCommands } from "./group.js";
import { mediaCommands } from "./media.js";
import { downloadCommands } from "./download.js";
import { dpCommands } from "./dp.js";
import { ownerCommands } from "./owner.js";

export const commands = new Map();

function register(list) {
  for (const cmd of list) {
    for (const alias of [cmd.name, ...(cmd.aliases || [])]) {
      commands.set(alias, cmd);
    }
  }
}

register(generalCommands);
register(groupCommands);
register(mediaCommands);
register(downloadCommands);
register(dpCommands);
register(ownerCommands);

export function listCommandsByCategory() {
  const byCategory = {};
  const seen = new Set();
  for (const cmd of commands.values()) {
    if (seen.has(cmd.name)) continue;
    seen.add(cmd.name);
    byCategory[cmd.category] = byCategory[cmd.category] || [];
    byCategory[cmd.category].push(cmd);
  }
  return byCategory;
}
